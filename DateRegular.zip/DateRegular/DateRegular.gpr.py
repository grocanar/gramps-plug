#
# Gramps - a GTK+/GNOME based genealogy program
#
# Copyright (C) 2017       Dave Scheipers
# Copyright (C) 2017       Paul Culley
#
# This program is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation; either version 2 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program; if not, write to the Free Software
# Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA 02110-1301 USA.
#

"""
Filter rule to match Families with a particular value of child
"""
register(RULE,
  id    = 'DateRegular',
  name  = _("Event with regular date"),
  description = _("Matches Event with Regular Date"),
  version = '1.0.3',
  authors = ["Eric Doutreleau"],
  authors_email = ["eric@doutreleau.fr"],
  gramps_target_version  = '5.1',
  status = STABLE,
  fname = "DateRegular.py",
  ruleclass = 'DateRegular',  # must be rule class name
  namespace = 'Event',  # one of the primary object classes
  )
